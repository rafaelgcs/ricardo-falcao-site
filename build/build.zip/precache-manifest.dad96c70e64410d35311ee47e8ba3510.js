self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "482205492e432d9c6ed16dba5d921dd9",
    "url": "/rf/index.html"
  },
  {
    "revision": "9cca4037b7d65b17b368",
    "url": "/rf/static/css/2.01f3a2a8.chunk.css"
  },
  {
    "revision": "e65dbdf1dc581af9ac18",
    "url": "/rf/static/css/main.a9c5950c.chunk.css"
  },
  {
    "revision": "9cca4037b7d65b17b368",
    "url": "/rf/static/js/2.d828e045.chunk.js"
  },
  {
    "revision": "b46eae19120e0343c25f399c83a404d7",
    "url": "/rf/static/js/2.d828e045.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e65dbdf1dc581af9ac18",
    "url": "/rf/static/js/main.1b197a04.chunk.js"
  },
  {
    "revision": "f43e1d48141bb605d1db",
    "url": "/rf/static/js/runtime-main.210bae3c.js"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/rf/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/rf/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "5e3708b65d34a054d8341f29bf8a62d9",
    "url": "/rf/static/media/bg-02.5e3708b6.jpg"
  },
  {
    "revision": "0cb5a5c0d251c109458c85c6afeffbaa",
    "url": "/rf/static/media/fa-brands-400.0cb5a5c0.svg"
  },
  {
    "revision": "13685372945d816a2b474fc082fd9aaa",
    "url": "/rf/static/media/fa-brands-400.13685372.ttf"
  },
  {
    "revision": "a06da7f0950f9dd366fc9db9d56d618a",
    "url": "/rf/static/media/fa-brands-400.a06da7f0.woff2"
  },
  {
    "revision": "c1868c9545d2de1cf8488f1dadd8c9d0",
    "url": "/rf/static/media/fa-brands-400.c1868c95.eot"
  },
  {
    "revision": "ec3cfddedb8bebd2d7a3fdf511f7c1cc",
    "url": "/rf/static/media/fa-brands-400.ec3cfdde.woff"
  },
  {
    "revision": "261d666b0147c6c5cda07265f98b8f8c",
    "url": "/rf/static/media/fa-regular-400.261d666b.eot"
  },
  {
    "revision": "89ffa3aba80d30ee0a9371b25c968bbb",
    "url": "/rf/static/media/fa-regular-400.89ffa3ab.svg"
  },
  {
    "revision": "c20b5b7362d8d7bb7eddf94344ace33e",
    "url": "/rf/static/media/fa-regular-400.c20b5b73.woff2"
  },
  {
    "revision": "db78b9359171f24936b16d84f63af378",
    "url": "/rf/static/media/fa-regular-400.db78b935.ttf"
  },
  {
    "revision": "f89ea91ecd1ca2db7e09baa2c4b156d1",
    "url": "/rf/static/media/fa-regular-400.f89ea91e.woff"
  },
  {
    "revision": "1ab236ed440ee51810c56bd16628aef0",
    "url": "/rf/static/media/fa-solid-900.1ab236ed.ttf"
  },
  {
    "revision": "a0369ea57eb6d3843d6474c035111f29",
    "url": "/rf/static/media/fa-solid-900.a0369ea5.eot"
  },
  {
    "revision": "b15db15f746f29ffa02638cb455b8ec0",
    "url": "/rf/static/media/fa-solid-900.b15db15f.woff2"
  },
  {
    "revision": "bea989e82b07e9687c26fc58a4805021",
    "url": "/rf/static/media/fa-solid-900.bea989e8.woff"
  },
  {
    "revision": "ec763292e583294612f124c0b0def500",
    "url": "/rf/static/media/fa-solid-900.ec763292.svg"
  },
  {
    "revision": "34c7ddc8e144bcaf8ece30ccabb66269",
    "url": "/rf/static/media/logo_azul.34c7ddc8.png"
  },
  {
    "revision": "f06406c863939ab567ec027f7b8195d3",
    "url": "/rf/static/media/logo_white.f06406c8.png"
  },
  {
    "revision": "729aa97c3e9a7ca023887b7d63839296",
    "url": "/rf/static/media/ricardo.729aa97c.png"
  },
  {
    "revision": "b7c9e1e479de3b53f1e4e30ebac2403a",
    "url": "/rf/static/media/slick.b7c9e1e4.woff"
  },
  {
    "revision": "ced611daf7709cc778da928fec876475",
    "url": "/rf/static/media/slick.ced611da.eot"
  },
  {
    "revision": "d41f55a78e6f49a5512878df1737e58a",
    "url": "/rf/static/media/slick.d41f55a7.ttf"
  },
  {
    "revision": "f97e3bbf73254b0112091d0192f17aec",
    "url": "/rf/static/media/slick.f97e3bbf.svg"
  }
]);